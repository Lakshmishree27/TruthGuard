"""
main.py
-------
The FastAPI backend. This is the "engine room" of TruthGuard: it wires
together retrieval -> generation -> verification -> decision into one
API endpoint.

Run it with:
    uvicorn main:app --reload

Then open http://localhost:8000/docs to test it interactively.
"""

from fastapi import FastAPI
from pydantic import BaseModel

import config
import retrieval
import llm_client
import verification

app = FastAPI(title="TruthGuard API")


class QueryRequest(BaseModel):
    question: str


class QueryResponse(BaseModel):
    question: str
    answer: str
    verification_status: str          # ACCEPT / WARNING / REJECT
    truth_probability_score: float
    signals: dict
    evidence: list


@app.post("/query", response_model=QueryResponse)
def query(request: QueryRequest):
    # 1. Retrieve relevant evidence (RAG)
    evidence = retrieval.retrieve_evidence(request.question)

    # 2. Build a grounded prompt and generate the main answer + samples
    prompt = llm_client.build_grounded_prompt(request.question, evidence)
    generation = llm_client.generate_responses(prompt)

    # 3. Verify: similarity + self-consistency + uncertainty -> TPS
    result = verification.compute_truth_probability_score(
        main_response=generation["main_response"],
        sample_responses=generation["sample_responses"],
        evidence=evidence,
        logprobs=generation["main_logprobs"],
    )

    # 4. Decision engine
    status = verification.decide(result["tps"])

    return QueryResponse(
        question=request.question,
        answer=generation["main_response"],
        verification_status=status,
        truth_probability_score=result["tps"],
        signals=result,
        evidence=evidence,
    )


@app.get("/")
def health_check():
    return {"status": "TruthGuard API is running", "llm_backend": config.LLM_BACKEND}
