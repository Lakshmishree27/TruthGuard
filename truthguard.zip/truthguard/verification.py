"""
verification.py
----------------
This is the heart of TruthGuard. It computes the THREE independent
signals described in your report:

1. Semantic Similarity  -> does the answer match the retrieved evidence?
2. Self-Consistency      -> do repeated generations agree with each other?
3. Uncertainty/Entropy   -> how confident was the model while generating?
"""

import math
import numpy as np
from sentence_transformers import SentenceTransformer

import config

_embedding_model = None


def _get_embedding_model():
    global _embedding_model
    if _embedding_model is None:
        _embedding_model = SentenceTransformer(config.EMBEDDING_MODEL_NAME)
    return _embedding_model


def cosine_similarity(vec_a, vec_b):
    vec_a, vec_b = np.array(vec_a), np.array(vec_b)
    denom = (np.linalg.norm(vec_a) * np.linalg.norm(vec_b))
    if denom == 0:
        return 0.0
    return float(np.dot(vec_a, vec_b) / denom)


def semantic_similarity_score(response: str, evidence: list) -> float:
    """
    Embeds the response and each evidence chunk, then returns the
    highest similarity found (i.e. "is there at least one fact that
    strongly supports this answer?").
    """
    if not evidence:
        return 0.0
    model = _get_embedding_model()
    response_vec = model.encode([response])[0]
    evidence_vecs = model.encode([e["text"] for e in evidence])

    sims = [cosine_similarity(response_vec, ev) for ev in evidence_vecs]
    return max(sims)


def self_consistency_score(main_response: str, sample_responses: list) -> float:
    """
    Embeds the main response and each sampled variation, then averages
    how similar they are. High similarity = the model keeps saying the
    same thing = more likely to be a real fact, not a hallucination.
    """
    if not sample_responses:
        return 1.0  # nothing to compare against; assume consistent
    model = _get_embedding_model()
    main_vec = model.encode([main_response])[0]
    sample_vecs = model.encode(sample_responses)

    sims = [cosine_similarity(main_vec, sv) for sv in sample_vecs]
    return float(np.mean(sims))


def token_entropy_score(logprobs: list) -> float:
    """
    Classic entropy-based uncertainty, used when the LLM backend gives
    us token log-probabilities (currently: OpenAI backend).

    Returns a NORMALIZED entropy value between 0 (very confident) and 1
    (very uncertain).
    """
    if not logprobs:
        return None  # signal "not available" -> caller should use fallback

    probs = [math.exp(lp) for lp in logprobs]
    # Shannon "surprisal" per token: -log(p). Average it, then squash to 0-1.
    surprisals = [-lp for lp in logprobs]
    avg_surprisal = float(np.mean(surprisals))

    # Squash into [0,1] with a soft cap (tune the divisor for your model)
    normalized = min(1.0, avg_surprisal / 5.0)
    return normalized


def semantic_entropy_fallback(main_response: str, sample_responses: list) -> float:
    """
    Used when token logprobs aren't available (e.g. Ollama backend).
    Approximates "uncertainty" as how much the sampled responses
    disagree with each other in meaning -- if they scatter in different
    directions, the model is effectively uncertain, even without
    access to raw probabilities. (This mirrors the semantic entropy
    idea from Farquhar & Kossen, 2024, cited in your literature review.)

    Returns normalized entropy in [0, 1].
    """
    consistency = self_consistency_score(main_response, sample_responses)
    # High consistency -> low entropy. Simple inverse mapping.
    return 1.0 - consistency


def compute_truth_probability_score(main_response: str, sample_responses: list,
                                     evidence: list, logprobs: list):
    """
    Combines all three signals into the final Truth Probability Score,
    using the exact weighting formula from your report:

        TPS = 0.5 * similarity + 0.3 * consistency + 0.2 * (1 - entropy)
    """
    similarity = semantic_similarity_score(main_response, evidence)
    consistency = self_consistency_score(main_response, sample_responses)

    entropy = token_entropy_score(logprobs)
    entropy_source = "token_logprobs"
    if entropy is None:
        entropy = semantic_entropy_fallback(main_response, sample_responses)
        entropy_source = "semantic_entropy_fallback"

    tps = (
        config.WEIGHT_SIMILARITY * similarity
        + config.WEIGHT_CONSISTENCY * consistency
        + config.WEIGHT_UNCERTAINTY * (1 - entropy)
    )
    tps = round(float(max(0.0, min(1.0, tps))), 3)

    return {
        "tps": tps,
        "semantic_similarity": round(similarity, 3),
        "self_consistency": round(consistency, 3),
        "normalized_entropy": round(entropy, 3),
        "entropy_source": entropy_source,
    }


def decide(tps: float) -> str:
    if tps >= config.THRESHOLD_ACCEPT:
        return "ACCEPT"
    elif tps >= config.THRESHOLD_WARN:
        return "WARNING"
    else:
        return "REJECT"
