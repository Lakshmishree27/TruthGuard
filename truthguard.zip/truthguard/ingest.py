"""
ingest.py
---------
Run this once (and again anytime you add new documents) to build the
vector database that TruthGuard retrieves evidence from.

What it does, in plain terms:
1. Reads every .txt file in data/knowledge_base/
2. Splits them into individual lines/sentences ("chunks")
3. Converts each chunk into a numerical vector (embedding)
4. Stores those vectors in ChromaDB so we can search them later by meaning,
   not just keywords.

Usage:
    python ingest.py
"""

import os
import glob
import chromadb
from sentence_transformers import SentenceTransformer

import config


def load_chunks_from_files(folder):
    chunks = []
    for filepath in glob.glob(os.path.join(folder, "*.txt")):
        with open(filepath, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:  # skip blank lines
                    chunks.append(line)
    return chunks


def main():
    print("Loading source documents...")
    chunks = load_chunks_from_files(config.KNOWLEDGE_BASE_DIR)
    print(f"Found {len(chunks)} text chunks.")

    print(f"Loading embedding model '{config.EMBEDDING_MODEL_NAME}' (first run downloads it)...")
    model = SentenceTransformer(config.EMBEDDING_MODEL_NAME)

    print("Computing embeddings...")
    embeddings = model.encode(chunks, show_progress_bar=True).tolist()

    print("Writing to ChromaDB...")
    client = chromadb.PersistentClient(path=config.CHROMA_DB_DIR)

    # Start fresh each time so re-running ingest.py doesn't duplicate data
    try:
        client.delete_collection(config.COLLECTION_NAME)
    except Exception:
        pass

    collection = client.create_collection(config.COLLECTION_NAME)
    collection.add(
        documents=chunks,
        embeddings=embeddings,
        ids=[f"chunk_{i}" for i in range(len(chunks))],
    )

    print(f"Done. {len(chunks)} chunks stored in '{config.CHROMA_DB_DIR}'.")


if __name__ == "__main__":
    main()
