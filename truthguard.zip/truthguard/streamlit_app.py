"""
streamlit_app.py
----------------
A simple web UI for demoing TruthGuard, no frontend coding needed.

Run it with:
    streamlit run streamlit_app.py

(Make sure the FastAPI backend is also running: uvicorn main:app --reload)
"""

import streamlit as st
import requests

API_URL = "http://localhost:8000/query"

st.set_page_config(page_title="TruthGuard", page_icon="🛡️")
st.title("🛡️ TruthGuard")
st.caption("A Self-Verifying RAG Engine for Real-Time Hallucination Recognition and Mitigation")

question = st.text_input("Ask a question (try something from your knowledge base, e.g. 'Who walked on the Moon first?')")

if st.button("Submit") and question:
    with st.spinner("Retrieving evidence, generating and verifying response..."):
        try:
            res = requests.post(API_URL, json={"question": question}, timeout=180)
            res.raise_for_status()
            data = res.json()
        except Exception as e:
            st.error(f"Could not reach the backend. Is it running? ({e})")
            st.stop()

    status = data["verification_status"]
    tps = data["truth_probability_score"]

    color = {"ACCEPT": "green", "WARNING": "orange", "REJECT": "red"}[status]
    st.markdown(f"### Answer")
    st.write(data["answer"])

    st.markdown(f"### Verification: :{color}[{status}]")
    st.metric("Truth Probability Score (TPS)", tps)

    with st.expander("See verification signal breakdown"):
        st.json(data["signals"])

    with st.expander("See retrieved evidence"):
        for e in data["evidence"]:
            st.write(f"- ({e['similarity']:.2f}) {e['text']}")
