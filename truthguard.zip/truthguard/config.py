"""
config.py
---------
All the "knobs" for TruthGuard live here so you don't have to hunt
through every file to change a setting.
"""

import os

# --- Embedding model (turns text into vectors for similarity search) ---
# This runs locally, free, no API key needed.
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"

# --- Vector database location ---
CHROMA_DB_DIR = "./chroma_store"
COLLECTION_NAME = "truthguard_knowledge"

# --- Where your source documents live ---
KNOWLEDGE_BASE_DIR = "./data/knowledge_base"

# --- LLM backend ---
# TruthGuard supports two backends. Pick ONE by setting LLM_BACKEND:
#   "openai"  -> uses OpenAI's API (needs OPENAI_API_KEY env var). Gives token
#                logprobs, so uncertainty scoring is most accurate.
#   "ollama"  -> uses a locally running free model via Ollama (no API key,
#                no cost, runs on your own machine). Logprobs aren't
#                available, so uncertainty is estimated a different way
#                (explained in verification.py).
LLM_BACKEND = os.environ.get("TRUTHGUARD_LLM_BACKEND", "ollama")

OPENAI_MODEL = "gpt-4o-mini"
OLLAMA_MODEL = "llama3"
OLLAMA_BASE_URL = "http://localhost:11434"

# --- How many extra samples to generate for self-consistency checking ---
NUM_SAMPLES = 3
SAMPLING_TEMPERATURE = 0.9

# --- How many documents to retrieve per query ---
TOP_K_DOCS = 3

# --- Truth Probability Score weights (must sum to 1.0) ---
# These match the formula in your report:
# TPS = 0.5*Semantic Similarity + 0.3*Self-Consistency + 0.2*(1 - Normalized Entropy)
WEIGHT_SIMILARITY = 0.5
WEIGHT_CONSISTENCY = 0.3
WEIGHT_UNCERTAINTY = 0.2

# --- Decision thresholds ---
THRESHOLD_ACCEPT = 0.7   # TPS >= this -> Accept
THRESHOLD_WARN = 0.4     # TPS >= this (but < accept) -> Warning
                          # below this -> Reject
