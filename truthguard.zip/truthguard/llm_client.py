"""
llm_client.py
-------------
Handles talking to the actual language model. Supports two backends
so you can start for free (Ollama, local) or upgrade to OpenAI later.

Both backends expose one function: generate_responses(), which returns
the MAIN answer plus a few extra "sampled" answers (used later for
self-consistency checking) and, if available, token-level logprobs
(used for uncertainty/entropy scoring).
"""

import math
import requests

import config


def _generate_openai(prompt: str, n_samples: int, temperature: float):
    import openai  # imported here so Ollama users don't need this installed

    client = openai.OpenAI()  # reads OPENAI_API_KEY from environment
    responses = []
    logprobs_list = []

    for i in range(n_samples + 1):  # +1 for the main response
        completion = client.chat.completions.create(
            model=config.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.0 if i == 0 else temperature,  # main answer = deterministic
            logprobs=True,
        )
        choice = completion.choices[0]
        responses.append(choice.message.content)

        token_logprobs = [t.logprob for t in choice.logprobs.content] if choice.logprobs else []
        logprobs_list.append(token_logprobs)

    return {
        "main_response": responses[0],
        "sample_responses": responses[1:],
        "main_logprobs": logprobs_list[0],  # list of floats, or [] if unavailable
    }


def _generate_ollama(prompt: str, n_samples: int, temperature: float):
    """
    Ollama's local API doesn't expose token logprobs by default, so we
    can't compute classic entropy here. Instead, verification.py falls
    back to a "semantic entropy" proxy: how much the sampled answers
    disagree with each other in meaning (this mirrors the semantic
    entropy technique from Farquhar & Kossen, referenced in the report).
    """
    responses = []

    for i in range(n_samples + 1):
        payload = {
            "model": config.OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.0 if i == 0 else temperature,
            },
        }
        r = requests.post(f"{config.OLLAMA_BASE_URL}/api/generate", json=payload, timeout=120)
        r.raise_for_status()
        responses.append(r.json().get("response", "").strip())

    return {
        "main_response": responses[0],
        "sample_responses": responses[1:],
        "main_logprobs": [],  # not available from Ollama
    }


def generate_responses(prompt: str, n_samples: int = None, temperature: float = None):
    n_samples = n_samples if n_samples is not None else config.NUM_SAMPLES
    temperature = temperature if temperature is not None else config.SAMPLING_TEMPERATURE

    if config.LLM_BACKEND == "openai":
        return _generate_openai(prompt, n_samples, temperature)
    elif config.LLM_BACKEND == "ollama":
        return _generate_ollama(prompt, n_samples, temperature)
    else:
        raise ValueError(f"Unknown LLM_BACKEND: {config.LLM_BACKEND}")


def build_grounded_prompt(question: str, evidence: list):
    """
    Combines the user's question with retrieved evidence into a single
    prompt, instructing the model to answer only from the evidence.
    """
    context_text = "\n".join(f"- {e['text']}" for e in evidence)
    prompt = f"""Answer the question using ONLY the facts listed below.
If the facts don't contain the answer, say "I don't have enough information."

Facts:
{context_text}

Question: {question}

Answer concisely:"""
    return prompt
